/**
 * Lab 5, Exercise 4 (Intermediate): output differs depending on whether a METHOD or a FIELD is
 * accessed through a superclass reference. Explanation at the bottom.
 */
class Parent {
    String name = "Parent field";
    String getName() { return "Parent method"; }
    static String kind() { return "Parent static method"; }
}

class Child extends Parent {
    String name = "Child field";                         // HIDES the field, does not override it
    @Override String getName() { return "Child method"; }
    static String kind() { return "Child static method"; }   // HIDES, does not override
}

public class Ex4_FieldVsMethod {
    public static void main(String[] args) {
        Parent p = new Child();        // declared type Parent, actual object Child

        System.out.println(p.getName());   // Child method  -> methods are polymorphic
        System.out.println(p.name);        // Parent field  -> fields follow the DECLARED type
        System.out.println(Parent.kind()); // static methods follow the class they are called on

        Child c = (Child) p;
        System.out.println(c.name);        // Child field   -> now the declared type is Child

        /*
         * EXPLANATION: an overridden method is chosen by the JVM at RUN time from the object's real
         * class (dynamic dispatch). Fields and static methods are not overridden, only hidden. The
         * compiler resolves them from the DECLARED type of the variable, so p.name gives Parent's field.
         */
    }
}
