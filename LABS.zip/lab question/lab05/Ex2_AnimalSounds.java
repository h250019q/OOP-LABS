/** Lab 5, Exercise 2 (Basic): Animal with sound() and Cat, Cow, Duck stored in an Animal[]. */
class Animal {
    String sound() { return "..."; }
}
class Cat extends Animal {
    @Override String sound() { return "Meow"; }
}
class Cow extends Animal {
    @Override String sound() { return "Moo"; }
}
class Duck extends Animal {
    @Override String sound() { return "Quack"; }
}

public class Ex2_AnimalSounds {
    public static void main(String[] args) {
        // EXPLAIN: upcasting: one array type holds several different subclass objects
        Animal[] farm = { new Cat(), new Cow(), new Duck(), new Animal() };

        for (Animal a : farm) {
            // EXPLAIN: the JVM picks sound() from the ACTUAL object at run time (dynamic dispatch)
            System.out.println(a.getClass().getSimpleName() + " says " + a.sound());
        }
    }
}
