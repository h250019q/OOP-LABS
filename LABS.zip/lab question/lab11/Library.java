import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class Library {

    // Collections keyed by id (requirement)
    private final Map<String, LibraryItem> items = new LinkedHashMap<>();
    private final Map<String, Member> members = new LinkedHashMap<>();
    private final List<LibraryListener> listeners = new ArrayList<>();

    // ---------- Observer ----------
    public void subscribe(LibraryListener l) { listeners.add(l); }
    private void fire(String message) { for (LibraryListener l : listeners) l.onEvent(message); }

    // ---------- Setup ----------
    public void addItem(LibraryItem item) {
        if (items.containsKey(item.getId()))
            throw new IllegalArgumentException("Item id already exists: " + item.getId());
        items.put(item.getId(), item);
        fire("Added " + item.type().toLowerCase() + ": " + item.getTitle());
    }

    public void registerMember(Member m) {
        if (members.containsKey(m.getId()))
            throw new IllegalArgumentException("Member id already exists: " + m.getId());
        members.put(m.getId(), m);
        fire("Registered member: " + m.getName());
    }

    // ---------- Core service ----------
    public void borrow(String memberId, String itemId)
            throws ItemNotAvailableException, MemberLimitExceededException {
        borrow(memberId, itemId, LocalDate.now());
    }

    public void borrow(String memberId, String itemId, LocalDate on)
            throws ItemNotAvailableException, MemberLimitExceededException {
        // 1. look up member and item (IllegalArgumentException if missing)
        Member member = requireMember(memberId);
        LibraryItem item = requireItem(itemId);

        // 2. check the member's loan limit and the item's availability
        if (!member.canBorrow()) {
            throw new MemberLimitExceededException(
                member.getName() + " already has " + Member.MAX_LOANS + " loans", Member.MAX_LOANS);
        }
        item.borrow(member);                 // throws ItemNotAvailableException if on loan

        // 3. create the Loan and record it on the member
        Loan loan = new Loan(member, item, on);
        member.addLoan(loan);
        fire(member.getName() + " borrowed '" + item.getTitle() + "', due " + loan.getDueOn());
    }

    public void giveBack(String memberId, String itemId) {
        Member member = requireMember(memberId);
        LibraryItem item = requireItem(itemId);
        Loan loan = member.getLoans().stream()
                .filter(l -> l.getItem() == item)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        member.getName() + " has not borrowed '" + item.getTitle() + "'"));
        member.removeLoan(loan);
        item.giveBack();
        fire(member.getName() + " returned '" + item.getTitle() + "'");
    }

    // ---------- Queries (streams) ----------
    public List<Loan> overdueLoans(LocalDate today) {
        return members.values().stream()
                .flatMap(m -> m.getLoans().stream())
                .filter(l -> l.isOverdue(today))
                .sorted(Comparator.comparing(Loan::getDueOn))
                .toList();
    }

    public List<LibraryItem> searchByTitle(String text) {
        return items.values().stream()
                .filter(i -> i.getTitle().toLowerCase().contains(text.toLowerCase()))
                .sorted(Comparator.comparing(LibraryItem::getTitle))
                .toList();
    }

    public Collection<LibraryItem> allItems()   { return Collections.unmodifiableCollection(items.values()); }
    public Collection<Member> allMembers()      { return Collections.unmodifiableCollection(members.values()); }

    private Member requireMember(String id) {
        Member m = members.get(id);
        if (m == null) throw new IllegalArgumentException("No such member: " + id);
        return m;
    }
    private LibraryItem requireItem(String id) {
        LibraryItem i = items.get(id);
        if (i == null) throw new IllegalArgumentException("No such item: " + id);
        return i;
    }

    // ---------- Persistence (Lab 10) ----------
    public void save(Path dir) throws IOException {
        Files.createDirectories(dir);
        Files.write(dir.resolve("items.csv"),
                items.values().stream().map(LibraryItem::toCsv).toList());
        Files.write(dir.resolve("members.csv"),
                members.values().stream().map(Member::toCsv).toList());
        Files.write(dir.resolve("loans.csv"),
                members.values().stream().flatMap(m -> m.getLoans().stream())
                        .map(Loan::toCsv).collect(Collectors.toList()));
    }

    public void load(Path dir) throws IOException {
        items.clear(); members.clear();
        for (String line : readLines(dir.resolve("items.csv")))   addItemQuietly(ItemFactory.fromCsv(line));
        for (String line : readLines(dir.resolve("members.csv"))) {
            String[] p = line.split(",", -1);
            members.put(p[0], new Member(p[0], p[1]));
        }
        for (String line : readLines(dir.resolve("loans.csv"))) {
            String[] p = line.split(",", -1);
            Member m = requireMember(p[0]);
            LibraryItem it = requireItem(p[1]);
            try {
                it.borrow(m);                                   // restores the 'on loan' state
            } catch (ItemNotAvailableException e) {
                throw new IOException("Corrupt data: " + e.getMessage(), e);
            }
            m.addLoan(new Loan(m, it, LocalDate.parse(p[2])));
        }
    }

    private void addItemQuietly(LibraryItem i) { items.put(i.getId(), i); }

    private List<String> readLines(Path file) throws IOException {
        if (!Files.exists(file)) return List.of();              // first run
        return Files.readAllLines(file).stream().filter(l -> !l.isBlank()).toList();
    }
}
