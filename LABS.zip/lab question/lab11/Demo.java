import java.nio.file.Path;
import java.time.LocalDate;

// Scripted walk-through that exercises every requirement without typing at the menu.
public class Demo {
    public static void main(String[] args) throws Exception {
        Library lib = new Library();
        lib.subscribe(msg -> System.out.println("[event] " + msg));

        lib.addItem(new Book("B1", "Clean Code", "Robert Martin"));
        lib.addItem(new Book("B2", "Effective Java", "Joshua Bloch"));
        lib.addItem(new Book("B3", "Java Concurrency in Practice", "Brian Goetz"));
        lib.addItem(new Dvd("D1", "The Imitation Game", 114));
        lib.addItem(ItemFactory.fromCsv("BOOK,B4,Head First Java,Kathy Sierra"));
        lib.registerMember(new Member("M1", "Tariro"));
        lib.registerMember(new Member("M2", "Farai"));

        System.out.println("\n--- Borrowing ---");
        lib.borrow("M1", "B1", LocalDate.now().minusDays(20));   // backdated -> overdue (14 day loan)
        lib.borrow("M1", "D1", LocalDate.now().minusDays(10));   // backdated -> overdue (7 day loan)
        lib.borrow("M1", "B2");

        System.out.println("\n--- Error handling ---");
        try { lib.borrow("M1", "B3"); }
        catch (MemberLimitExceededException e) { System.out.println("Limit: " + e.getMessage()); }
        try { lib.borrow("M2", "B1"); }
        catch (ItemNotAvailableException e) { System.out.println("Unavailable: " + e.getMessage()); }
        try { lib.borrow("M9", "B1"); }
        catch (IllegalArgumentException e) { System.out.println("Invalid: " + e.getMessage()); }

        System.out.println("\n--- Overdue ---");
        lib.overdueLoans(LocalDate.now()).forEach(l -> System.out.println("OVERDUE: " + l));

        System.out.println("\n--- Search 'java' ---");
        lib.searchByTitle("java").forEach(System.out::println);

        System.out.println("\n--- Persistence round trip ---");
        Path dir = Path.of("demo-data");
        lib.save(dir);
        Library reloaded = new Library();
        reloaded.load(dir);
        reloaded.allItems().forEach(System.out::println);
        reloaded.overdueLoans(LocalDate.now()).forEach(l -> System.out.println("OVERDUE after reload: " + l));

        System.out.println("\n--- Return ---");
        lib.giveBack("M1", "B1");
        System.out.println("Overdue now: " + lib.overdueLoans(LocalDate.now()).size());
    }
}
