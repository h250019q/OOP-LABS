// OBSERVER pattern: the Library notifies any subscribed listener; it does not know what they do.
@FunctionalInterface
public interface LibraryListener {
    void onEvent(String message);
}
