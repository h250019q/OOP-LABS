import java.util.ArrayList;
import java.util.List;

public class Member {
    public static final int MAX_LOANS = 3;

    private final String id;
    private String name;
    private final List<Loan> loans = new ArrayList<>();

    public Member(String id, String name) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Member id required");
        this.id = id.trim();
        setName(name);
    }

    public void setName(String name) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Member name required");
        this.name = name.trim().replace(',', ' ');
    }

    public String getId()   { return id; }
    public String getName() { return name; }
    public boolean canBorrow() { return loans.size() < MAX_LOANS; }

    // read-only view: callers cannot change the list behind our back (Lab 3, defensive copy)
    public List<Loan> getLoans() { return List.copyOf(loans); }

    // package-private: only Library changes a member's loans
    void addLoan(Loan loan)    { loans.add(loan); }
    void removeLoan(Loan loan) { loans.remove(loan); }

    public String toCsv() { return id + "," + name; }

    @Override
    public String toString() {
        return String.format("%s %s (%d/%d loans)", id, name, loans.size(), MAX_LOANS);
    }
}
