public class Book extends LibraryItem {
    private final String author;

    public Book(String id, String title, String author) {
        super(id, title);
        this.author = (author == null || author.isBlank()) ? "Unknown" : author.trim().replace(',', ' ');
    }

    public String getAuthor() { return author; }

    @Override public int loanPeriodDays() { return 14; }
    @Override public String type()        { return "BOOK"; }
    @Override protected String extra()    { return author; }
}
