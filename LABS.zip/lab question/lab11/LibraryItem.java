// ABSTRACTION + ENCAPSULATION: common state and rules for everything the library lends.
public abstract class LibraryItem implements Borrowable {
    private final String id;
    private final String title;
    private Member borrower;                    // null when the item is on the shelf

    protected LibraryItem(String id, String title) {
        if (id == null || id.isBlank())       throw new IllegalArgumentException("Item id required");
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Title required");
        this.id = id.trim();
        this.title = title.trim().replace(',', ' ');   // commas would break the CSV format
    }

    // POLYMORPHISM: each subclass supplies its own values
    public abstract int loanPeriodDays();
    public abstract String type();
    protected abstract String extra();          // author for a Book, minutes for a Dvd

    public String getId()        { return id; }
    public String getTitle()     { return title; }
    public boolean isAvailable() { return borrower == null; }

    @Override
    public void borrow(Member member) throws ItemNotAvailableException {
        if (!isAvailable()) {
            throw new ItemNotAvailableException("'" + title + "' is already on loan to " + borrower.getName());
        }
        this.borrower = member;
    }

    @Override
    public void giveBack() { this.borrower = null; }

    public String toCsv() { return type() + "," + id + "," + title + "," + extra(); }

    @Override
    public String toString() {
        return String.format("[%s] %-6s %-28s %s", type(), id, title,
                isAvailable() ? "available" : "on loan to " + borrower.getName());
    }
}
