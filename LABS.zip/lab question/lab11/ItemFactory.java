// FACTORY pattern: callers ask for an item by type name and never use 'new Book'/'new Dvd' directly.
public class ItemFactory {
    private ItemFactory() { }

    public static LibraryItem fromCsv(String line) {
        String[] p = line.split(",", -1);
        if (p.length < 4) throw new IllegalArgumentException("Bad item line: " + line);
        return switch (p[0].toUpperCase()) {
            case "BOOK" -> new Book(p[1], p[2], p[3]);
            case "DVD"  -> new Dvd(p[1], p[2], Integer.parseInt(p[3]));
            default     -> throw new IllegalArgumentException("Unknown item type: " + p[0]);
        };
    }
}
