import java.time.LocalDate;

public class Loan {
    private final Member member;
    private final LibraryItem item;
    private final LocalDate borrowedOn;
    private final LocalDate dueOn;

    public Loan(Member member, LibraryItem item, LocalDate borrowedOn) {
        this.member = member;
        this.item = item;
        this.borrowedOn = borrowedOn;
        this.dueOn = borrowedOn.plusDays(item.loanPeriodDays());   // polymorphic call
    }

    public Member getMember()        { return member; }
    public LibraryItem getItem()     { return item; }
    public LocalDate getBorrowedOn() { return borrowedOn; }
    public LocalDate getDueOn()      { return dueOn; }

    public boolean isOverdue(LocalDate today) { return today.isAfter(dueOn); }

    public String toCsv() { return member.getId() + "," + item.getId() + "," + borrowedOn; }

    @Override
    public String toString() {
        return String.format("%s -> '%s' (due %s)", member.getName(), item.getTitle(), dueOn);
    }
}
