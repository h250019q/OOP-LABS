import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Path DATA = Path.of("data");

    public static void main(String[] args) {
        Library lib = new Library();
        lib.subscribe(msg -> System.out.println("  [event] " + msg));   // Observer as a lambda

        try {
            lib.load(DATA);
            System.out.println("Loaded " + lib.allItems().size() + " items, "
                               + lib.allMembers().size() + " members.");
        } catch (IOException | RuntimeException e) {
            System.out.println("Could not load saved data (" + e.getMessage() + "). Starting empty.");
        }

        Scanner in = new Scanner(System.in);
        boolean running = true;
        while (running) {
            printMenu();
            String choice = in.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> addItem(lib, in);
                    case "2" -> {
                        lib.registerMember(new Member(ask(in, "Member id: "), ask(in, "Name: ")));
                    }
                    case "3" -> lib.borrow(ask(in, "Member id: "), ask(in, "Item id: "));
                    case "4" -> lib.giveBack(ask(in, "Member id: "), ask(in, "Item id: "));
                    case "5" -> {
                        List<Loan> overdue = lib.overdueLoans(LocalDate.now());
                        if (overdue.isEmpty()) System.out.println("  No overdue items.");
                        else overdue.forEach(l -> System.out.println("  OVERDUE: " + l));
                    }
                    case "6" -> {
                        List<LibraryItem> found = lib.searchByTitle(ask(in, "Search text: "));
                        if (found.isEmpty()) System.out.println("  No matches.");
                        else found.forEach(i -> System.out.println("  " + i));
                    }
                    case "7" -> lib.allItems().forEach(i -> System.out.println("  " + i));
                    case "8" -> lib.allMembers().forEach(m -> System.out.println("  " + m));
                    case "0" -> running = false;
                    default  -> System.out.println("  Unknown option.");
                }
            } catch (ItemNotAvailableException | MemberLimitExceededException e) {
                System.out.println("  Cannot borrow: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("  Invalid input: " + e.getMessage());
            }
        }

        try {
            lib.save(DATA);
            System.out.println("Data saved to " + DATA.toAbsolutePath());
        } catch (IOException e) {
            System.out.println("Save failed: " + e.getMessage());
        }
    }

    private static void addItem(Library lib, Scanner in) {
        String type = ask(in, "Type (book/dvd): ").toLowerCase();
        String id = ask(in, "Item id: ");
        String title = ask(in, "Title: ");
        switch (type) {
            case "book" -> lib.addItem(new Book(id, title, ask(in, "Author: ")));
            case "dvd"  -> {
                try {
                    lib.addItem(new Dvd(id, title, Integer.parseInt(ask(in, "Minutes: "))));
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("Minutes must be a whole number");
                }
            }
            default -> throw new IllegalArgumentException("Type must be book or dvd");
        }
    }

    private static String ask(Scanner in, String prompt) {
        System.out.print(prompt);
        return in.nextLine().trim();
    }

    private static void printMenu() {
        System.out.println("""

            ===== Library Menu =====
            1 Add item          5 List overdue
            2 Register member   6 Search by title
            3 Borrow            7 List all items
            4 Return            8 List members
            0 Save and exit
            Choose:""");
    }
}
