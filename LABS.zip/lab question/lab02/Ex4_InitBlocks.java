/** Lab 2, Exercise 4 (Intermediate): two static blocks and two instance blocks. Predict, then verify. */
public class Ex4_InitBlocks {

    static { System.out.println("static block 1"); }
    { System.out.println("instance block 1"); }
    static { System.out.println("static block 2"); }
    { System.out.println("instance block 2"); }

    Ex4_InitBlocks() { System.out.println("constructor"); }

    public static void main(String[] args) {
        /*
         * PREDICTION (written before running):
         *   static block 1
         *   static block 2          <- static blocks run ONCE, in written order, when the class loads
         *   --- first object ---
         *   instance block 1
         *   instance block 2
         *   constructor             <- instance blocks run before the constructor, for EVERY object
         *   --- second object ---
         *   instance block 1
         *   instance block 2
         *   constructor
         * The program output below matches this prediction.
         */
        System.out.println("--- first object ---");
        new Ex4_InitBlocks();
        System.out.println("--- second object ---");
        new Ex4_InitBlocks();
    }
}
