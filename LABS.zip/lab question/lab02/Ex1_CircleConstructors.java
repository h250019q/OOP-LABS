/** Lab 2, Exercise 1 (Basic): constructors for Circle, including a default radius of 1.0. */
public class Ex1_CircleConstructors {
    public static void main(String[] args) {
        Circle big = new Circle(5.5);     // uses the constructor with a radius
        Circle unit = new Circle();       // uses the no-argument constructor -> radius 1.0

        System.out.println("big radius  = " + big.getRadius());
        System.out.println("unit radius = " + unit.getRadius());
        System.out.printf("unit area    = %.4f%n", unit.area());
    }
}
