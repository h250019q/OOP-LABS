# Lab 11: Design Patterns and Mini-Project: Library Management System

## How to run

```bash
javac *.java          # compile everything
java Main             # interactive menu (data saved in ./data on exit)
java Demo             # scripted walk-through of every requirement
```
Requires JDK 17 or later.

## Design patterns (Lab 11 theory)

| Pattern | Where it is used | Problem solved |
| --- | --- | --- |
| Factory | `ItemFactory.fromCsv` | Rebuilds the right `Book` or `Dvd` from a text line, so no other class hard-codes concrete types |
| Observer | `LibraryListener`, `Library.subscribe` and `fire` | The library announces events (borrow, return, add) without knowing who listens; `Main` subscribes a lambda that prints them |
| Strategy (via polymorphism) | `loanPeriodDays()` | Each item type supplies its own loan rule, so `Loan` works unchanged for new item types |
| Singleton | Not used | `Library` is created once in `Main`; the pattern is only worth adding when a single shared instance is really required |

## Requirement checklist

| Requirement | Where it is met |
| --- | --- |
| Book, Member, Loan with private fields, validation, toString | `Book`, `Member`, `Loan`; constructors reject blank ids and names and non-positive running times |
| Abstract `LibraryItem` with `Book` and `Dvd`, each with `loanPeriodDays()` | `LibraryItem` is abstract; Book = 14 days, Dvd = 7 days |
| `Borrowable` interface with `borrow(Member)` and `giveBack()` | `Borrowable`, implemented once in `LibraryItem` |
| `ItemNotAvailableException` and `MemberLimitExceededException` (max 3 loans) | Both are checked exceptions; the limit is `Member.MAX_LOANS` |
| Items and members in `Map<String, ...>` keyed by id | `Library.items`, `Library.members` |
| Persist to CSV on exit, reload on start | `Library.save` and `Library.load`; files `items.csv`, `members.csv`, `loans.csv` |
| Menu: add item, register member, borrow, return, overdue, search by title | `Main`; overdue and search use streams in `Library` |

## OOP principles demonstrated

- **Encapsulation:** all fields private; `Member.getLoans()` returns an unmodifiable copy; only `Library` can change a member's loans (package-private `addLoan` and `removeLoan`).
- **Inheritance and abstraction:** `LibraryItem` holds shared state and rules; `Book` and `Dvd` add only what differs.
- **Polymorphism:** `Library` and `Loan` call `loanPeriodDays()` on a `LibraryItem` reference.
- **Exceptions:** checked exceptions for expected business failures (item on loan, limit reached); `IllegalArgumentException` for bad input (unknown id, duplicate id, blank name).

## Class diagram

```mermaid
classDiagram
    class Borrowable {
        <<interface>>
        +borrow(Member)
        +giveBack()
    }
    class LibraryItem {
        <<abstract>>
        -id : String
        -title : String
        -borrower : Member
        +loanPeriodDays()* int
        +type()* String
        +isAvailable() boolean
    }
    class Book { -author : String }
    class Dvd { -minutes : int }
    class Member {
        -id : String
        -name : String
        +MAX_LOANS : int
        +canBorrow() boolean
    }
    class Loan {
        -borrowedOn : LocalDate
        -dueOn : LocalDate
        +isOverdue(LocalDate) boolean
    }
    class Library {
        -items : Map
        -members : Map
        +borrow(memberId, itemId)
        +giveBack(memberId, itemId)
        +overdueLoans(LocalDate) List
        +searchByTitle(String) List
        +save(Path)
        +load(Path)
    }
    class ItemFactory { +fromCsv(String) LibraryItem }
    class LibraryListener {
        <<interface>>
        +onEvent(String)
    }
    class ItemNotAvailableException
    class MemberLimitExceededException

    Borrowable <|.. LibraryItem
    LibraryItem <|-- Book
    LibraryItem <|-- Dvd
    Library "1" o-- "*" LibraryItem
    Library "1" o-- "*" Member
    Member "1" o-- "0..3" Loan
    Loan --> LibraryItem
    Loan --> Member
    Library ..> LibraryListener : notifies
    Library ..> ItemFactory : uses
    Library ..> ItemNotAvailableException : throws
    Library ..> MemberLimitExceededException : throws
```

## Testing

`Demo.java` checks, with backdated loans where needed: borrowing, the 3-loan limit, borrowing an item already on loan, an unknown member id, overdue detection, search, a save and reload round trip (loans and overdue status survive), and returning an item. The interactive menu was also checked across two runs to confirm that data persists.

## Known limitations

- Commas are replaced by spaces in titles, authors and names, because the CSV format does not quote fields.
- Borrow dates use today's date; `Library.borrow(memberId, itemId, date)` exists so overdue behaviour can be tested.
- No fines or renewals; these would be natural extensions (a fine `Strategy`, for example).
