import java.util.ArrayList;

/** Lab 8, Exercise 3 (Intermediate): a generic Stack<T> backed by an ArrayList<T>. */
class MyStack<T> {
    private final ArrayList<T> items = new ArrayList<>();    // T is chosen by whoever creates the stack

    void push(T item) { items.add(item); }                   // add to the top (end of the list)

    T pop() {
        if (isEmpty()) throw new RuntimeException("Stack is empty");
        return items.remove(items.size() - 1);               // remove and return the top
    }

    T peek() {
        if (isEmpty()) throw new RuntimeException("Stack is empty");
        return items.get(items.size() - 1);                  // look at the top without removing
    }

    boolean isEmpty() { return items.isEmpty(); }
}

public class Ex3_GenericStack {
    public static void main(String[] args) {
        MyStack<String> words = new MyStack<>();
        words.push("one");
        words.push("two");
        words.push("three");
        System.out.println("peek: " + words.peek());          // three
        System.out.println("pop:  " + words.pop());           // three  (last in, first out)
        System.out.println("pop:  " + words.pop());           // two

        MyStack<Integer> numbers = new MyStack<>();           // the SAME class works for Integer
        numbers.push(10);
        numbers.push(20);
        int top = numbers.pop();                              // no cast needed: the compiler knows it is Integer
        System.out.println("number popped: " + top);
        // numbers.push("text");   // COMPILE ERROR: type safety
    }
}
