import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Lab 8, Exercise 2 (Basic): remove duplicates from a list of names using a Set. */
public class Ex2_RemoveDuplicates {
    public static void main(String[] args) {
        List<String> names = List.of("Ann", "Ben", "Ann", "Cara", "Ben", "Dan");

        // EXPLAIN: a Set cannot hold duplicates; LinkedHashSet also keeps the order names first appeared
        Set<String> unique = new LinkedHashSet<>(names);

        System.out.println("Original: " + names);
        System.out.println("Unique:   " + unique);
    }
}
