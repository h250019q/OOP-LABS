/**
 * Lab 7, Exercise 4 (Intermediate): BankAccount.withdraw throws InsufficientFundsException instead
 * of returning false. Trade-offs are discussed at the bottom.
 */
class InsufficientFundsException extends Exception {
    private final double shortfall;

    InsufficientFundsException(String message, double shortfall) {
        super(message);
        this.shortfall = shortfall;
    }
    double getShortfall() { return shortfall; }
}

class BankAccount {
    private double balance;

    BankAccount(double balance) { this.balance = balance; }

    double getBalance() { return balance; }

    void withdraw(double amount) throws InsufficientFundsException {
        if (amount <= 0) throw new IllegalArgumentException("Withdrawal must be positive");
        if (amount > balance) {
            // The exception carries useful detail: how much is missing
            throw new InsufficientFundsException(
                    "Cannot withdraw " + amount + "; balance is " + balance, amount - balance);
        }
        balance -= amount;
    }
}

public class Ex4_WithdrawException {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount(100);
        try {
            acc.withdraw(60);
            System.out.println("Balance now " + acc.getBalance());
            acc.withdraw(60);                                  // fails
            System.out.println("not reached");
        } catch (InsufficientFundsException e) {
            System.out.println(e.getMessage());
            System.out.println("Short by " + e.getShortfall());
        }

        /*
         * TRADE-OFFS:
         *  + The failure cannot be ignored silently: the compiler forces callers to handle it.
         *  + The exception explains WHY it failed and carries extra data (the shortfall).
         *  + The normal path stays clean; error handling is separated into catch blocks.
         *  - More boilerplate, and changing the method signature breaks existing callers.
         *  - A boolean return is simpler for a routine, expected outcome, but it is easy to
         *    forget to check and it cannot say why the withdrawal failed.
         */
    }
}
