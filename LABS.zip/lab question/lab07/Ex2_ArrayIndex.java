/** Lab 7, Exercise 2 (Basic): access an array element and catch ArrayIndexOutOfBoundsException. */
public class Ex2_ArrayIndex {

    // Returns the element at index, or -1 if the index is invalid
    static int safeGet(int[] data, int index) {
        try {
            return data[index];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Invalid index " + index + ": " + e.getMessage());
            return -1;
        }
    }

    public static void main(String[] args) {
        int[] data = { 10, 20, 30 };
        System.out.println("data[1] = " + safeGet(data, 1));
        System.out.println("data[5] = " + safeGet(data, 5));      // out of range: caught, no crash
        System.out.println("The program carried on normally.");
    }
}
