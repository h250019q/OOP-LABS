/** Lab 4, Exercise 1: Student extends Person and adds a course. */
public class Student extends Person {
    private String course;

    public Student(String name, int age, String course) {
        super(name, age);          // EXPLAIN: must be first; runs Person's constructor
        this.course = course;
    }

    public String getCourse() { return course; }
}
