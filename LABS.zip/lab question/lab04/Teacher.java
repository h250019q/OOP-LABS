/** Lab 4, Exercise 2: Teacher also extends Person, reusing the same code as Student. */
public class Teacher extends Person {
    private String subject;

    public Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }

    public String getSubject() { return subject; }
}
