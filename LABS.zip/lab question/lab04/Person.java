/** Lab 4, Exercises 1 and 2: the superclass shared by Student and Teacher. */
public class Person {
    // protected: visible to subclasses (and the package), hidden from everyone else
    protected String name;
    protected int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Written ONCE here; Student and Teacher inherit it without rewriting it
    public void display() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}
