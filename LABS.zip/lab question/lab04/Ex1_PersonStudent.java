/** Lab 4, Exercise 1 (Basic): Person (name, age) and Student extends Person (adds course). */
public class Ex1_PersonStudent {
    public static void main(String[] args) {
        Person p = new Person("Mr Moyo", 45);
        Student s = new Student("Ada", 20, "Computer Science");

        p.display();
        s.display();       // display() was never written in Student: it is inherited from Person
        System.out.println("Ada studies " + s.getCourse());
    }
}
