/** Lab 4, Exercise 3 (Intermediate): Vehicle, Car, ElectricCar (multilevel). Trace constructor calls. */
class Vehicle {
    Vehicle() {
        System.out.println("1. Vehicle constructor");
    }
}

class Car extends Vehicle {
    Car() {
        // an implicit super() is inserted here by the compiler, so Vehicle() runs first
        System.out.println("2. Car constructor");
    }
}

class ElectricCar extends Car {
    ElectricCar() {
        // an implicit super() is inserted here, so Car() runs first (which in turn runs Vehicle())
        System.out.println("3. ElectricCar constructor");
    }
}

public class Ex3_ConstructorOrder {
    public static void main(String[] args) {
        // The chain runs from the TOP of the hierarchy downwards: Vehicle -> Car -> ElectricCar
        new ElectricCar();
    }
}
