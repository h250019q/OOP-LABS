import java.util.Iterator;

/**
 * Lab 9, Exercise 4 (Intermediate): a LinkedList with a private static nested Node class and an
 * inner Iterator class, so the list works in a for-each loop.
 */
class SimpleLinkedList<T> implements Iterable<T> {

    // STATIC NESTED class: it needs no outer instance, so it is declared static
    private static class Node<T> {
        T value;
        Node<T> next;
        Node(T value) { this.value = value; }
    }

    private Node<T> head;
    private Node<T> tail;

    void add(T value) {
        Node<T> node = new Node<>(value);
        if (head == null) {
            head = tail = node;          // first element
        } else {
            tail.next = node;            // link after the current last node
            tail = node;
        }
    }

    // Iterable requires iterator(); that is what makes for-each work
    @Override
    public Iterator<T> iterator() {
        return new ListIterator();
    }

    // INNER class (not static): it reads the outer object's 'head' field directly
    private class ListIterator implements Iterator<T> {
        private Node<T> current = head;

        @Override public boolean hasNext() { return current != null; }

        @Override public T next() {
            T value = current.value;
            current = current.next;
            return value;
        }
    }
}

public class Ex4_LinkedListNested {
    public static void main(String[] args) {
        SimpleLinkedList<String> list = new SimpleLinkedList<>();
        list.add("alpha");
        list.add("beta");
        list.add("gamma");

        for (String s : list) {          // works because SimpleLinkedList implements Iterable
            System.out.println(s);
        }
    }
}
