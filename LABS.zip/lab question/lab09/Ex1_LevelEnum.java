/** Lab 9, Exercise 1 (Basic): enum Level { LOW, MEDIUM, HIGH } and a switch that prints advice for each. */
enum Level { LOW, MEDIUM, HIGH }

public class Ex1_LevelEnum {

    static void advice(Level level) {
        // EXPLAIN: a switch expression over an enum; the compiler checks every constant is covered
        String message = switch (level) {
            case LOW    -> "Relax, nothing needs doing.";
            case MEDIUM -> "Keep an eye on it.";
            case HIGH   -> "Act immediately!";
        };
        System.out.println(level + ": " + message);
    }

    public static void main(String[] args) {
        for (Level l : Level.values()) {       // values() returns every constant in order
            advice(l);
        }
    }
}
