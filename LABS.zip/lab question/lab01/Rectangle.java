/**
 * Shared by Lab 1 Exercises 3 and 4: a simple Rectangle.
 * Fields are set directly because encapsulation is not introduced until Lab 3.
 */
public class Rectangle {
    double width;
    double height;

    double area()      { return width * height; }
    double perimeter() { return 2 * (width + height); }
}
