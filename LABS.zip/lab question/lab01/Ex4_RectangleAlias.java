/** Lab 1, Exercise 4 (Intermediate): predict then run the r2 = r1 aliasing program. */
public class Ex4_RectangleAlias {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle();
        r1.width = 5;
        r1.height = 2;

        // PREDICTION: r2 is not a copy, so changing r2.width will also change r1.width.
        Rectangle r2 = r1;       // EXPLAIN: copies the REFERENCE (address); both variables point to one object
        r2.width = 20;

        System.out.println("r1.width = " + r1.width);        // 20.0, not 5.0
        System.out.println("r1 == r2 ? " + (r1 == r2));      // true: same object

        /*
         * LAB RECORD EXPLANATION:
         * r1 and r2 are two names for the same object on the heap. Assigning one reference
         * variable to another copies the address, not the object. So a change made through r2
         * is visible through r1. To get an independent copy you must create a new object.
         */
        Rectangle r3 = new Rectangle();
        r3.width = r1.width;
        r3.height = r1.height;
        r3.width = 99;           // changing the copy leaves r1 alone
        System.out.println("r3.width = " + r3.width + ", but r1.width is still " + r1.width + " (r3 is a true copy)");
    }
}
