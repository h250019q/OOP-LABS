/** Lab 1, Exercise 2 (Basic): isAntique() returns true when a car is more than 25 years old. */
public class Ex2_CarAntique {
    public static void main(String[] args) {
        Car newer = new Car();
        newer.brand = "Toyota";
        newer.year = 2015;

        Car older = new Car();
        older.brand = "Honda";
        older.year = 1998;

        // 1998 is more than 25 years before the current year, so this is true
        System.out.println(older.brand + " antique? " + older.isAntique());
        // 2015 is not, so this is false
        System.out.println(newer.brand + " antique? " + newer.isAntique());
    }
}
