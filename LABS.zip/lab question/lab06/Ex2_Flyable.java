/** Lab 6, Exercise 2 (Basic): an interface Flyable implemented by two classes with NO common superclass. */
interface Flyable {
    void fly();          // implicitly public abstract
}

class Bird implements Flyable {
    @Override public void fly() { System.out.println("Bird flaps its wings and flies"); }
}

class Aeroplane implements Flyable {
    @Override public void fly() { System.out.println("Aeroplane flies using jet engines"); }
}

public class Ex2_Flyable {
    public static void main(String[] args) {
        // EXPLAIN: program to the interface. The variable type is Flyable, the objects are unrelated classes
        Flyable[] things = { new Bird(), new Aeroplane() };
        for (Flyable f : things) {
            f.fly();
        }
    }
}
