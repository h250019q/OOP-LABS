import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Lab 6, Exercise 4 (Intermediate): Student implements Comparable<Student> sorted by name,
 * then a Comparator sorts by marks.
 */
class Student implements Comparable<Student> {
    private final String name;
    private final int marks;

    Student(String name, int marks) { this.name = name; this.marks = marks; }

    String getName() { return name; }
    int getMarks()   { return marks; }

    // EXPLAIN: the NATURAL ordering of the class: alphabetical by name
    @Override
    public int compareTo(Student other) {
        return name.compareTo(other.name);
    }

    @Override
    public String toString() { return name + "(" + marks + ")"; }
}

public class Ex4_StudentComparable {
    public static void main(String[] args) {
        List<Student> list = new ArrayList<>(List.of(
                new Student("Zed", 90), new Student("Amy", 60), new Student("Kuda", 75)));

        Collections.sort(list);                                  // uses compareTo (by name)
        System.out.println("By name:        " + list);

        // EXPLAIN: a Comparator is an EXTERNAL ordering; a class can have many of them
        list.sort(Comparator.comparingInt(Student::getMarks).reversed());
        System.out.println("By marks (high):" + list);
    }
}
