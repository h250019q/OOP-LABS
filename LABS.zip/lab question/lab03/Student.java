/**
 * Lab 3, Exercises 1 and 2 (Basic): a Student with private name and marks (0 to 100).
 * Exercise 1: reject invalid marks in the setter.
 * Exercise 2: getGrade() works out the grade from the marks, without storing it in a field.
 * This file is the finished class for BOTH exercises.
 */
public class Student {

    // EXPLAIN: private -> no code outside this class can touch these directly
    private String name;
    private int marks;

    public Student(String name, int marks) {
        this.name = name;
        setMarks(marks);          // reuse the setter so the constructor validates too
    }

    public String getName() { return name; }
    public int getMarks()   { return marks; }

    // Exercise 1: the only way to change marks, and it enforces the 0..100 rule
    public void setMarks(int marks) {
        if (marks < 0 || marks > 100) {
            throw new IllegalArgumentException("Marks must be between 0 and 100, but got " + marks);
        }
        this.marks = marks;
    }

    // Exercise 2: derived on demand, so it can never disagree with the marks.
    // The grade boundaries are an assumption; change them to match your course scheme.
    public String getGrade() {
        if (marks >= 75) return "A";
        if (marks >= 60) return "B";
        if (marks >= 50) return "C";
        return "F";
    }
}
