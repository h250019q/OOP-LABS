import java.util.List;

/**
 * Lab 3, Exercise 4 (Intermediate): an ImmutablePerson. Each design choice is explained.
 */
// (1) final class: nobody can subclass it and sneak in mutable behaviour
final class ImmutablePerson {

    // (2) final fields: each is assigned once, in the constructor, and never again
    private final String name;
    private final int age;
    private final List<String> hobbies;

    ImmutablePerson(String name, int age, List<String> hobbies) {
        this.name = name;
        this.age = age;
        // (3) defensive copy: if the caller later changes THEIR list, our copy is not affected
        this.hobbies = List.copyOf(hobbies);
    }

    // (4) getters only, no setters: state can never change after construction.
    // String and Integer are already immutable, so they are safe to return.
    String getName() { return name; }
    int getAge()     { return age; }

    // (5) the returned list is already unmodifiable, so returning it does not leak
    List<String> getHobbies() { return hobbies; }

    // To "change" a value we create a NEW object (like String methods do)
    ImmutablePerson withAge(int newAge) {
        return new ImmutablePerson(name, newAge, hobbies);
    }
}

public class Ex4_ImmutablePerson {
    public static void main(String[] args) {
        List<String> mine = new java.util.ArrayList<>(List.of("chess", "football"));
        ImmutablePerson p = new ImmutablePerson("Rudo", 20, mine);

        mine.add("gaming");                       // changing the original list...
        System.out.println("Hobbies in object: " + p.getHobbies());   // ...does not affect the person

        try {
            p.getHobbies().add("hacking");        // modifying through the getter is blocked
        } catch (UnsupportedOperationException e) {
            System.out.println("Cannot modify hobbies through the getter");
        }

        ImmutablePerson older = p.withAge(21);
        System.out.println(p.getName() + " is " + p.getAge() + ", new copy is " + older.getAge());
    }
}
