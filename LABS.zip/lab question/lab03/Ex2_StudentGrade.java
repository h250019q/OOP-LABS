/** Lab 3, Exercise 2 (Basic): getGrade() returns A, B, C or F, with no grade field stored. */
public class Ex2_StudentGrade {
    public static void main(String[] args) {
        int[] testMarks = { 90, 65, 52, 30 };
        for (int m : testMarks) {
            Student s = new Student("Test", m);
            System.out.println(m + " marks -> grade " + s.getGrade());
        }
    }
}
