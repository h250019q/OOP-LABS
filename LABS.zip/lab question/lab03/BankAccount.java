import java.util.ArrayList;
import java.util.List;

/** Lab 3, Exercise 3: the Lab 3 BankAccount extended with a transaction history. */
public class BankAccount {
    private final String accountNumber;
    private double balance;

    // The history is private and mutable; callers only ever see a copy (see getHistory)
    private final List<String> history = new ArrayList<>();

    public BankAccount(String accountNumber, double openingBalance) {
        if (openingBalance < 0) throw new IllegalArgumentException("Opening balance cannot be negative");
        this.accountNumber = accountNumber;
        this.balance = openingBalance;
        history.add("OPEN " + openingBalance);
    }

    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
        balance += amount;
        history.add("DEPOSIT " + amount);
    }

    public boolean withdraw(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Withdrawal must be positive");
        if (amount > balance) {
            history.add("FAILED WITHDRAW " + amount);
            return false;
        }
        balance -= amount;
        history.add("WITHDRAW " + amount);
        return true;
    }

    public double getBalance() { return balance; }

    // EXPLAIN: List.copyOf returns an UNMODIFIABLE COPY, so the caller cannot alter our real list
    public List<String> getHistory() {
        return List.copyOf(history);
    }
}
