import java.util.List;

/** Lab 10, Exercise 4 (Intermediate): print the names of students above the class average, sorted alphabetically. */
record Student(String name, double marks) { }

public class Ex4_AboveAverage {
    public static void main(String[] args) {
        List<Student> students = List.of(
                new Student("Zed", 80), new Student("Amy", 90),
                new Student("Bob", 50), new Student("Cai", 85));

        // Stream step 1: work out the class average
        double average = students.stream().mapToDouble(Student::marks).average().orElse(0);
        System.out.println("Class average: " + average);

        // Stream step 2: filter -> map -> sorted -> print (a stream does not change the original list)
        System.out.println("Above average:");
        students.stream()
                .filter(s -> s.marks() > average)       // lambda: keep only students above average
                .map(Student::name)                     // method reference: turn each Student into its name
                .sorted()                               // natural (alphabetical) order
                .forEach(name -> System.out.println("  " + name));
    }
}
