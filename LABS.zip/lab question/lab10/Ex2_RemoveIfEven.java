import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/** Lab 10, Exercise 2 (Basic): use a Predicate and removeIf to delete all even numbers from a list. */
public class Ex2_RemoveIfEven {
    public static void main(String[] args) {
        // Must be a mutable list: List.of(...) is immutable and removeIf would throw an exception
        List<Integer> numbers = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6, 7, 8));

        // EXPLAIN: Predicate<T> is a functional interface with one method, boolean test(T)
        Predicate<Integer> isEven = n -> n % 2 == 0;

        numbers.removeIf(isEven);               // removes every element for which the predicate is true
        System.out.println(numbers);            // [1, 3, 5, 7]
    }
}
